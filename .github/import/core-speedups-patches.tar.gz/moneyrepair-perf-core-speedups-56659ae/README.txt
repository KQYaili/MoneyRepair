MoneyRepair patch bundle: perf/core-speedups

Branch:       perf/core-speedups
Base commit:  da354f04648dd12a76060be6d0b8c58ef228c245 (origin/main)
Head commit:  56659ae450ca32a399eb26c7005c3677b43dfef2
Result tree:  71de5e9cd37ccee6145a190b3038eb4579fc5b5b
Created with: git format-patch --binary --full-index origin/main..HEAD

Apply:
  sha256sum -c SHA256SUMS
  git checkout -b perf/core-speedups da354f04648dd12a76060be6d0b8c58ef228c245
  git am --3way 0001-*.patch 0002-*.patch 0003-*.patch 0004-*.patch
  git rev-parse HEAD^{tree}    # expect 71de5e9cd37ccee6145a190b3038eb4579fc5b5b

Simulation-only: output-identical v4.4.1 core speedup, measurement tools,
x86 equivalence workflow, and docs/v5_core_performance_audit.md.
